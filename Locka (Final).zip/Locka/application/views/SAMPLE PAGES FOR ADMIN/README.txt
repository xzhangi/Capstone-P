This folder contains the sample pages for the admin page, if you need the page, copy it out and paste it in the view folder
1. change file extension from .html to .php