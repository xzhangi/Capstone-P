<div class="medium-img">
	<img src="assets/default-BS/img/lockers/medium2.png" alt="">
</div>
<div class="cbp-l-member-info">
	<div class="cbp-l-member-name">Medium Locker</div>
	<div class="cbp-l-member-position">20 x 8 x 6 inches</div>
	<div class="cbp-l-member-desc">
	</div>
</div>
