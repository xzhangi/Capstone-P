<div class="small-img">
	<img src="assets/default-BS/img/lockers/small2.png" alt="">
</div>
<div class="cbp-l-member-info">
	<div class="cbp-l-member-name">Small Locker</div>
	<div class="cbp-l-member-position">10 x 5 x 4 inches</div>
	<div class="cbp-l-member-desc">
	</div>
</div>
