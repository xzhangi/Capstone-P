<div class="big-img">
	<img src="assets/default-BS/img/lockers/big2.png" alt="">
</div>
<div class="cbp-l-member-info">
	<div class="cbp-l-member-name">Big Locker</div>
	<div class="cbp-l-member-position">30 x 12 x 8 inches</div>
	<div class="cbp-l-member-desc">
	</div>
</div>
